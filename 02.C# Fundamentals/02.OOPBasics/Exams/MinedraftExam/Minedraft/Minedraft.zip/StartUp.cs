﻿using System;

namespace Minedraft
{
    class StartUp
    {
        static void Main()
        {
            
        }
    }
}
