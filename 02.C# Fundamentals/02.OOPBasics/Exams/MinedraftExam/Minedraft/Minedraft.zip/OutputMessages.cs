﻿public static class OutputMessages
{
    public static string InvaildEnergy => "Harvester is not registered, because of it's {0}";

    public static string InvalidEnergyOutput => "";
}

