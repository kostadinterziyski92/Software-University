﻿public interface IRefuable
{
    void Refuel(double literes);
}

