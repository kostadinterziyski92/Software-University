﻿public interface IFuel
{
    double Fuel { get; }

    double Consumption { get; }
}

