﻿public interface IDrivable
{
    void Drive(double distance);
}

